g++ -o main main.cpp equal.cpp one_queue_unequal.cpp multiple_queues_unequal.cpp dynamic.cpp

